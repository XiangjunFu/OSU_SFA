package edu.osu.sfal.util;

import edu.osu.sfal.Main;

public class TestMain {
	public static void main(String[] args) throws Exception {
		Main.main(args);
	}
}
